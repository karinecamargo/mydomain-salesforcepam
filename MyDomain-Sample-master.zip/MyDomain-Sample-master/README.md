MyDomain-Sample
====================

A simple example to brand your Salesforce My Domain

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://heroku.com/deploy?template=https://github.com/salesforceidentity/MyDomain-Sample)

The new design of https://login.salesforce.com requires that your My Domain page is responsive.   It will automatically scale up and down depending on the size of a user's browser.   This sample should aid with that.

The page itself will scale up on both veritical and horizontal dimensions indefinetely.   The minimum width is 511px;


